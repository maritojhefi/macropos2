<?php

use App\Http\Controllers\InstallHelperController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// installer routes
// Route::group([ 'middleware' => [ 'is_verified', 'need_to_install']], function () {
//     Route::get('/', function () {
//         return view('landing');
//     });
// });