

<?php $__env->startSection('template_title'); ?>
  <?php echo e(trans('installer_messages.purchase_code.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  <?php echo e(trans('installer_messages.purchase_code.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
  <?php if(\Session::has('msg')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('msg'); ?></li>
        </ul>
    </div>
  <?php endif; ?>
  <form method="post" action="<?php echo e(route('verifyPurchaseCode')); ?>" class="tabs-wrap">
    <?php echo csrf_field(); ?>
    <div class="form-group <?php echo e($errors->has('name') ? ' has-error ' : ''); ?>">
      <label for="name">
          <?php echo e(trans('installer_messages.purchase_code.buyer_name')); ?>

      </label>
      <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(trans('installer_messages.purchase_code.buyer_name_placeholder')); ?>" required />
      <?php if($errors->has('name')): ?>
          <span class="error-block">
              <i class="fa fa-fw fa-exclamation-triangle" aria-hidden="true"></i>
              <?php echo e($errors->first('name')); ?>

          </span>
      <?php endif; ?>
    </div>
    <div class="form-group <?php echo e($errors->has('email') ? ' has-error ' : ''); ?>">
      <label for="email">
          <?php echo e(trans('installer_messages.purchase_code.buyer_email')); ?>

      </label>
      <input type="text" name="email" id="email"  value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(trans('installer_messages.purchase_code.buyer_email_placeholder')); ?>" required />
      <?php if($errors->has('email')): ?>
          <span class="error-block">
              <i class="fa fa-fw fa-exclamation-triangle" aria-hidden="true"></i>
              <?php echo e($errors->first('email')); ?>

          </span>
      <?php endif; ?>
    </div>
    <div class="form-group <?php echo e($errors->has('purchase_code') ? ' has-error ' : ''); ?>">
      <label for="purchase_code">
          <?php echo e(trans('installer_messages.purchase_code.code')); ?>

      </label>
      <input type="text" name="purchase_code" id="purchase_code" placeholder="<?php echo e(trans('installer_messages.purchase_code.code')); ?>"  required />
      <?php if($errors->has('purchase_code')): ?>
          <span class="error-block">
              <i class="fa fa-fw fa-exclamation-triangle" aria-hidden="true"></i>
              <?php echo e($errors->first('purchase_code')); ?>

          </span>
      <?php endif; ?>
    </div>
    <div class="buttons">
      <button class="button" type="submit">
        <?php echo e(trans('installer_messages.purchase_code.next')); ?>

        <i class="fa fa-angle-right fa-fw" aria-hidden="true"></i>
      </button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\acculance-v1\resources\views/vendor/installer/verify.blade.php ENDPATH**/ ?>