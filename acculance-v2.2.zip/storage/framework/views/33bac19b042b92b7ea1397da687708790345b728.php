<?php
$config = [
    'appName' => config('app.name'),
    'locale' => ($locale = app()->getLocale()),
    'locales' => config('app.locales'),
    'githubAuth' => config('services.github.client_id'),
];
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" href='<?php echo e(asset('images/'.config('config.favicon'))); ?>'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(mix('/dist/css/app.css')); ?>">
</head>

<body class="hold-transition layout-footer-fixed">
    <div id="app"></div>

    
    <script>
        window.config = <?php echo json_encode($config, 15, 512) ?>;
    </script>

    

    <script src="<?php echo e(mix('/dist/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\acculance-v1\resources\views/spa.blade.php ENDPATH**/ ?>