<template>
  <div>
      <div class="ticket" id="test">
          <img src="http://acculance.test/images/logo-black.png" alt="Logo">
          <p class="centered">RECEIPT EXAMPLE
              <br>Address line 1
              <br>Address line 2</p>
          <table>
              <thead>
                  <tr>
                      <th class="quantity">Q.</th>
                      <th class="description">Description</th>
                      <th class="price">$$</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td class="quantity">1.00</td>
                      <td class="description">ARDUINO UNO R3</td>
                      <td class="price">$25.00</td>
                  </tr>
                  <tr>
                      <td class="quantity">2.00</td>
                      <td class="description">JAVASCRIPT BOOK</td>
                      <td class="price">$10.00</td>
                  </tr>
                  <tr>
                      <td class="quantity">1.00</td>
                      <td class="description">STICKER PACK</td>
                      <td class="price">$10.00</td>
                  </tr>
                  <tr>
                      <td class="quantity"></td>
                      <td class="description">TOTAL</td>
                      <td class="price">$55.00</td>
                  </tr>
              </tbody>
          </table>
          <p class="centered">Thanks for your purchase!
              <br>parzibyte.me/blog</p>
      </div>
      <button id="btnPrint" class="hidden-print" @click="printInvoice">Print</button>
  </div>
</template>

<script>

export default {
  methods: {
    printInvoice() {
      var a = document.getElementById('test').innerHTML;

    },
  }
}
</script>

<style scoped>
* {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.description,
th.description {
    width: 75px;
    max-width: 75px;
}

td.quantity,
th.quantity {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
}

@media print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}
</style>
